Smart Hood Solution — Complete Editable Website

Included:
- Professional responsive website
- Your Smart Hood Solution logo
- All supplied hood images
- Box / Flat / Glass / Commercial Hood gallery
- Cleaning packages
- Booking form -> WhatsApp
- Local booking storage + lightweight admin panel
- Customer review manager
- Google Maps button
- Call + WhatsApp buttons
- Pricing section

Admin:
- Demo PIN: 1234
- Change ADMIN_PIN in index.html before publishing.

Important:
The included admin panel uses browser localStorage, so it is a lightweight demo/admin system and does not sync between devices.
For a true multi-device admin dashboard with secure login and a central customer database, a backend/database must be connected.
